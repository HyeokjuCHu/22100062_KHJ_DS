#include <iostream>

using namespace std;

class Product{
private:
    string pcode;
    string pname;
    int cost;
    int leftN;
    int disc;
public:
    Product()
    : pcode(""),pname(""),cost(0),leftN(0),disc(0){}

    int getSalePrice()  {
        return cost * (100 - disc) / 100;
    }
    string getCode() {
        return pcode;
    }

    string getName()  {
        return pname;
    }

    int getCost() {
        return cost;
    }

    int getDiscount()  {
        return disc;
    }

    int TotalPrice(int *x, int n){
        int sum=0;
        for(int i=0;i<n;i++){
            sum+=x[i].cost;
        }
        return sum;
    }
    
    void display() {
        cout <<"["<< pcode<<"] " << getSalePrice()<< pname<<endl;
    }

    int Max()
};

int main(){
    
    int a;
    cin>>a;
    Product List[a];

    int *x=new int[a];

    for(int i=0;i<a;i++){
        string name, code;
        int price, disc, left;
        cin.ignore(); // Clear any pending newline characters
        getline(cin, code);
        cin >> price >> left >> disc;
        cin.ignore(); // Clear any pending newline characters
        getline(cin, name);
        List[i] = Product(code, name, price, left, disc);
        
    }

    for(int i=0;i<a;i++){
        List.display();
    }

    return 0;
}